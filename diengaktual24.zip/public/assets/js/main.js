// Diengaktual24 — frontend publik (vanilla JS, tanpa framework, ringan)

const PLACEHOLDER_IMG =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="250"><rect width="100%" height="100%" fill="%23efece4"/></svg>`
  ).replace(/%23/g, '#');

function esc(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}

function formatDate(iso) {
  try {
    const d = new Date(iso.replace(' ', 'T') + 'Z');
    return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' }) + ' WIB';
  } catch {
    return iso;
  }
}

function updateClock() {
  const el = document.getElementById('live-clock');
  if (!el) return;
  const now = new Date();
  el.textContent = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' WIB';
}
setInterval(updateClock, 1000);
updateClock();

async function loadCategories() {
  const nav = document.getElementById('category-nav');
  if (!nav) return;
  try {
    const res = await fetch('/api/categories');
    const data = await res.json();
    const params = new URLSearchParams(location.search);
    const active = params.get('kategori');
    const ul = document.createElement('ul');
    const homeLi = document.createElement('li');
    homeLi.innerHTML = `<a href="/" class="${!active ? 'active' : ''}">Beranda</a>`;
    ul.appendChild(homeLi);
    data.categories.forEach((c) => {
      const li = document.createElement('li');
      li.innerHTML = `<a href="/?kategori=${encodeURIComponent(c.slug)}" class="${active === c.slug ? 'active' : ''}">${esc(c.name)}</a>`;
      ul.appendChild(li);
    });
    nav.innerHTML = '';
    nav.appendChild(ul);
  } catch (e) {
    console.error('Gagal memuat kategori', e);
  }
}

function articleCardHTML(a) {
  const img = a.image_url || PLACEHOLDER_IMG;
  return `
    <a class="news-card" href="/artikel/${encodeURIComponent(a.slug)}">
      <img class="thumb" src="${esc(img)}" alt="${esc(a.title)}" loading="lazy" onerror="this.src='${PLACEHOLDER_IMG}'">
      <div class="body">
        <span class="eyebrow-sm">${esc(a.category_name || 'Berita')}</span>
        <h3>${esc(a.title)}</h3>
        <p class="excerpt">${esc(a.excerpt || '')}</p>
        <span class="meta">${formatDate(a.created_at)}</span>
      </div>
    </a>`;
}

function heroSideItemHTML(a) {
  const img = a.image_url || PLACEHOLDER_IMG;
  return `
    <a class="side-item" href="/artikel/${encodeURIComponent(a.slug)}">
      <img src="${esc(img)}" alt="${esc(a.title)}" loading="lazy" onerror="this.src='${PLACEHOLDER_IMG}'">
      <div>
        <span class="eyebrow-sm">${esc(a.category_name || 'Berita')}</span>
        <h3>${esc(a.title)}</h3>
      </div>
    </a>`;
}

let currentPage = 1;

async function loadHome() {
  const heroEl = document.getElementById('hero-section');
  const gridEl = document.getElementById('news-grid');
  const titleEl = document.getElementById('grid-title');
  const paginationEl = document.getElementById('pagination');
  if (!gridEl) return;

  const params = new URLSearchParams(location.search);
  const kategori = params.get('kategori');
  const q = params.get('q');
  currentPage = parseInt(params.get('page') || '1', 10);

  gridEl.innerHTML = '<div class="loading-state">Memuat berita…</div>';
  if (heroEl) heroEl.innerHTML = '';

  const apiParams = new URLSearchParams({ page: currentPage, limit: kategori || q ? 12 : 13 });
  if (kategori) apiParams.set('kategori', kategori);
  if (q) apiParams.set('q', q);

  try {
    const res = await fetch(`/api/articles?${apiParams.toString()}`);
    const data = await res.json();
    const articles = data.articles || [];

    if (titleEl) {
      if (q) titleEl.firstChild.textContent = `Hasil pencarian: "${q}"`;
      else if (kategori) {
        const catName = document.querySelector(`#category-nav a.active`);
        titleEl.firstChild.textContent = catName ? catName.textContent : 'Kategori';
      } else {
        titleEl.firstChild.textContent = 'Berita Terkini';
      }
    }

    if (!articles.length) {
      gridEl.innerHTML = '<div class="empty-state">Belum ada berita untuk ditampilkan.</div>';
      if (paginationEl) paginationEl.innerHTML = '';
      return;
    }

    let listForGrid = articles;

    // Tampilkan hero hanya di halaman 1 tanpa filter kategori/pencarian
    if (heroEl && currentPage === 1 && !kategori && !q && articles.length >= 4) {
      const [main, ...rest] = articles;
      const sideItems = rest.slice(0, 3);
      listForGrid = rest.slice(3);
      const img = main.image_url || PLACEHOLDER_IMG;
      heroEl.innerHTML = `
        <div class="hero-main">
          <a href="/artikel/${encodeURIComponent(main.slug)}">
            <img src="${esc(img)}" alt="${esc(main.title)}" onerror="this.src='${PLACEHOLDER_IMG}'">
            <span class="eyebrow">${esc(main.category_name || 'Berita Utama')}</span>
            <h1>${esc(main.title)}</h1>
            <p class="excerpt">${esc(main.excerpt || '')}</p>
            <span class="byline">Oleh ${esc(main.author)} · ${formatDate(main.created_at)}</span>
          </a>
        </div>
        <div class="hero-side">
          ${sideItems.map(heroSideItemHTML).join('')}
        </div>`;
    }

    gridEl.innerHTML = listForGrid.map(articleCardHTML).join('');

    if (paginationEl) {
      const hasPrev = currentPage > 1;
      const hasNext = currentPage < data.totalPages;
      paginationEl.innerHTML = `
        <button id="prev-btn" ${!hasPrev ? 'disabled' : ''}>&larr; Sebelumnya</button>
        <span class="current">Halaman ${data.page} dari ${data.totalPages || 1}</span>
        <button id="next-btn" ${!hasNext ? 'disabled' : ''}>Berikutnya &rarr;</button>
      `;
      const prevBtn = document.getElementById('prev-btn');
      const nextBtn = document.getElementById('next-btn');
      if (prevBtn) prevBtn.onclick = () => goToPage(currentPage - 1);
      if (nextBtn) nextBtn.onclick = () => goToPage(currentPage + 1);
    }
  } catch (e) {
    gridEl.innerHTML = '<div class="empty-state">Gagal memuat berita. Coba muat ulang halaman.</div>';
    console.error(e);
  }
}

function goToPage(page) {
  const params = new URLSearchParams(location.search);
  params.set('page', page);
  location.search = params.toString();
}

async function loadTicker() {
  const el = document.getElementById('ticker-inner');
  if (!el) return;
  try {
    const res = await fetch('/api/articles?limit=8');
    const data = await res.json();
    const items = data.articles || [];
    if (!items.length) return;
    const html = items.map((a) => `<span>${esc(a.title)}</span>`).join('<span>&nbsp;&nbsp;&#9679;&nbsp;&nbsp;</span>');
    el.innerHTML = html + html; // digandakan untuk animasi scroll berkelanjutan
  } catch (e) {
    console.error('Gagal memuat ticker', e);
  }
}

function bindSearch() {
  const form = document.getElementById('search-form');
  if (!form) return;
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const q = document.getElementById('search-input').value.trim();
    if (q) location.href = `/?q=${encodeURIComponent(q)}`;
  });
}

// ===== Halaman detail artikel =====
async function loadArticlePage() {
  const container = document.getElementById('article-container');
  if (!container) return;

  // Jika halaman ini sudah dirender di server (lihat functions/artikel/[slug].js),
  // kontennya sudah lengkap dan sudah menghitung 1 kali baca — jangan fetch ulang
  // supaya jumlah "kali dibaca" tidak dobel.
  if (document.querySelector('script[data-ssr="1"]')) return;

  const params = new URLSearchParams(location.search);
  const slug = params.get('slug') || container.dataset.slug;
  if (!slug) {
    container.innerHTML = '<div class="empty-state">Artikel tidak ditemukan.</div>';
    return;
  }
  try {
    const res = await fetch(`/api/articles/${encodeURIComponent(slug)}`);
    if (!res.ok) {
      container.innerHTML = '<div class="empty-state">Artikel tidak ditemukan atau belum dipublikasikan.</div>';
      return;
    }
    const { article } = await res.json();
    document.title = `${article.title} — Diengaktual24`;
    const img = article.image_url || PLACEHOLDER_IMG;
    const paragraphs = article.content
      .split(/\n+/)
      .filter((p) => p.trim())
      .map((p) => `<p>${esc(p)}</p>`)
      .join('');
    container.innerHTML = `
      <a class="back-link" href="/">&larr; Kembali ke beranda</a>
      <span class="eyebrow">${esc(article.category_name || 'Berita')}</span>
      <h1>${esc(article.title)}</h1>
      <div class="meta-row">
        <span>Oleh ${esc(article.author)}</span>
        <span>${formatDate(article.created_at)}</span>
        <span>${article.views} kali dibaca</span>
      </div>
      <img class="cover" src="${esc(img)}" alt="${esc(article.title)}" onerror="this.src='${PLACEHOLDER_IMG}'">
      <div class="article-body">${paragraphs}</div>
    `;
  } catch (e) {
    container.innerHTML = '<div class="empty-state">Gagal memuat artikel.</div>';
    console.error(e);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadCategories();
  bindSearch();
  loadTicker();
  loadHome();
  loadArticlePage();

  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    const q = new URLSearchParams(location.search).get('q');
    if (q) searchInput.value = q;
  }
});
