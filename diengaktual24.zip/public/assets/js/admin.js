// Diengaktual24 — logika panel admin (dashboard)

function esc(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}

function showAlert(type, message) {
  const box = document.getElementById('alert-box');
  box.innerHTML = `<div class="alert alert-${type}">${esc(message)}</div>`;
  window.scrollTo({ top: 0, behavior: 'smooth' });
  setTimeout(() => { box.innerHTML = ''; }, 5000);
}

let categoriesCache = [];

async function checkSession() {
  const res = await fetch('/api/me');
  if (!res.ok) {
    location.href = '/admin-diengaktual24/';
    return null;
  }
  const data = await res.json();
  document.getElementById('who').textContent = `Login sebagai: ${data.username}`;
  return data;
}

async function loadCategoriesIntoSelect() {
  const res = await fetch('/api/categories');
  const data = await res.json();
  categoriesCache = data.categories;
  const select = document.getElementById('category');
  select.innerHTML = data.categories.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join('');
}

function categoryName(id) {
  const c = categoriesCache.find((c) => c.id === id);
  return c ? c.name : '-';
}

async function loadArticleList() {
  const tbody = document.getElementById('article-rows');
  tbody.innerHTML = '<tr><td colspan="6">Memuat…</td></tr>';
  try {
    const res = await fetch('/api/articles?all=1&limit=50');
    const data = await res.json();
    if (!data.articles.length) {
      tbody.innerHTML = '<tr><td colspan="6">Belum ada artikel. Klik "+ Artikel Baru" untuk mulai menulis.</td></tr>';
      return;
    }
    tbody.innerHTML = data.articles
      .map(
        (a) => `
      <tr>
        <td>${esc(a.title)}</td>
        <td>${esc(a.category_name || '-')}</td>
        <td><span class="badge badge-${a.status}">${a.status === 'published' ? 'Tayang' : 'Draf'}</span></td>
        <td>${new Date(a.created_at.replace(' ', 'T') + 'Z').toLocaleDateString('id-ID')}</td>
        <td>${a.views}</td>
        <td class="row-actions">
          <button data-edit="${a.id}">Ubah</button>
          <button class="btn-danger" data-delete="${a.id}" data-title="${esc(a.title)}">Hapus</button>
        </td>
      </tr>`
      )
      .join('');

    tbody.querySelectorAll('[data-edit]').forEach((btn) => {
      btn.addEventListener('click', () => editArticle(btn.dataset.edit));
    });
    tbody.querySelectorAll('[data-delete]').forEach((btn) => {
      btn.addEventListener('click', () => deleteArticle(btn.dataset.delete, btn.dataset.title));
    });
  } catch (e) {
    tbody.innerHTML = '<tr><td colspan="6">Gagal memuat artikel.</td></tr>';
    console.error(e);
  }
}

function switchView(view) {
  document.getElementById('view-list').style.display = view === 'list' ? '' : 'none';
  document.getElementById('view-form').style.display = view === 'form' ? '' : 'none';
  document.getElementById('view-categories').style.display = view === 'categories' ? '' : 'none';
  document.querySelectorAll('.admin-nav button[data-view]').forEach((b) => b.classList.remove('active'));
  const navKey = view === 'form' ? 'new' : view;
  const navBtn = document.querySelector(`.admin-nav button[data-view="${navKey}"]`);
  if (navBtn) navBtn.classList.add('active');
}

function resetForm() {
  document.getElementById('article-form').reset();
  document.getElementById('article-id').value = '';
  document.getElementById('image_url').value = '';
  document.getElementById('form-title').textContent = 'Artikel Baru';
  setUploadStatus('', '');
  togglePreview('');
}

function setUploadStatus(text, kind) {
  const el = document.getElementById('upload-status');
  el.textContent = text;
  el.className = 'upload-status' + (kind ? ` ${kind}` : '');
}

function togglePreview(url) {
  const img = document.getElementById('photo_preview');
  if (url) {
    img.src = url;
    img.style.display = 'block';
  } else {
    img.style.display = 'none';
    img.removeAttribute('src');
  }
}

async function handlePhotoUpload(e) {
  const file = e.target.files[0];
  if (!file) return;

  setUploadStatus('Mengunggah…', '');
  const formData = new FormData();
  formData.append('file', file);

  try {
    const res = await fetch('/api/upload', { method: 'POST', body: formData });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Gagal mengunggah foto.');
    document.getElementById('image_url').value = data.url;
    document.getElementById('image_url_manual').value = '';
    togglePreview(data.url);
    setUploadStatus('Foto tersimpan ✓', 'ok');
  } catch (err) {
    setUploadStatus(err.message, 'err');
    e.target.value = '';
  }
}

async function editArticle(id) {
  try {
    const res = await fetch(`/api/articles/${id}`);
    const data = await res.json();
    const a = data.article;
    document.getElementById('article-id').value = a.id;
    document.getElementById('title').value = a.title;
    document.getElementById('category').value = a.category_id || '';
    document.getElementById('status').value = a.status;
    document.getElementById('image_url').value = a.image_url || '';
    document.getElementById('image_url_manual').value = a.image_url && !a.image_url.startsWith('/media/') ? a.image_url : '';
    togglePreview(a.image_url || '');
    setUploadStatus('', '');
    document.getElementById('excerpt').value = a.excerpt || '';
    document.getElementById('content').value = a.content;
    document.getElementById('form-title').textContent = 'Ubah Artikel';
    switchView('form');
    document.querySelector('.admin-nav button[data-view="new"]').classList.add('active');
  } catch (e) {
    showAlert('error', 'Gagal memuat artikel untuk diubah.');
  }
}

async function deleteArticle(id, title) {
  if (!confirm(`Hapus artikel "${title}"? Tindakan ini tidak bisa dibatalkan.`)) return;
  try {
    const res = await fetch(`/api/articles/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Gagal menghapus.');
    showAlert('success', 'Artikel berhasil dihapus.');
    loadArticleList();
  } catch (e) {
    showAlert('error', e.message);
  }
}

async function submitArticleForm(e) {
  e.preventDefault();
  const id = document.getElementById('article-id').value;
  const manualUrl = document.getElementById('image_url_manual').value.trim();
  const uploadedUrl = document.getElementById('image_url').value.trim();

  const payload = {
    title: document.getElementById('title').value.trim(),
    category_id: parseInt(document.getElementById('category').value, 10) || null,
    status: document.getElementById('status').value,
    image_url: manualUrl || uploadedUrl,
    excerpt: document.getElementById('excerpt').value.trim(),
    content: document.getElementById('content').value.trim(),
  };

  const saveBtn = document.getElementById('save-btn');
  saveBtn.disabled = true;
  saveBtn.textContent = 'Menyimpan…';

  try {
    const res = await fetch(id ? `/api/articles/${id}` : '/api/articles', {
      method: id ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Gagal menyimpan artikel.');
    showAlert('success', 'Artikel berhasil disimpan.');
    resetForm();
    switchView('list');
    loadArticleList();
  } catch (err) {
    showAlert('error', err.message);
  } finally {
    saveBtn.disabled = false;
    saveBtn.textContent = 'Simpan Artikel';
  }
}

async function loadCategoryManagement() {
  const tbody = document.getElementById('category-rows');
  tbody.innerHTML = '<tr><td colspan="3">Memuat…</td></tr>';
  try {
    const res = await fetch('/api/categories');
    const data = await res.json();
    categoriesCache = data.categories;
    if (!data.categories.length) {
      tbody.innerHTML = '<tr><td colspan="3">Belum ada kategori.</td></tr>';
      return;
    }
    tbody.innerHTML = data.categories
      .map(
        (c) => `
      <tr>
        <td>${esc(c.name)}</td>
        <td><code>${esc(c.slug)}</code></td>
        <td class="row-actions">
          <button class="btn-danger" data-del-cat="${c.id}" data-name="${esc(c.name)}">Hapus</button>
        </td>
      </tr>`
      )
      .join('');
    tbody.querySelectorAll('[data-del-cat]').forEach((btn) => {
      btn.addEventListener('click', () => deleteCategory(btn.dataset.delCat, btn.dataset.name));
    });
  } catch (e) {
    tbody.innerHTML = '<tr><td colspan="3">Gagal memuat kategori.</td></tr>';
  }
}

async function addCategory(e) {
  e.preventDefault();
  const input = document.getElementById('new-category-name');
  const name = input.value.trim();
  if (!name) return;
  try {
    const res = await fetch('/api/categories', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Gagal menambah kategori.');
    input.value = '';
    showAlert('success', 'Kategori berhasil ditambahkan.');
    await loadCategoryManagement();
    await loadCategoriesIntoSelect();
  } catch (err) {
    showAlert('error', err.message);
  }
}

async function deleteCategory(id, name) {
  if (!confirm(`Hapus kategori "${name}"? Artikel yang memakainya akan menjadi tanpa kategori.`)) return;
  try {
    const res = await fetch(`/api/categories/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Gagal menghapus kategori.');
    showAlert('success', 'Kategori berhasil dihapus.');
    await loadCategoryManagement();
    await loadCategoriesIntoSelect();
    await loadArticleList();
  } catch (err) {
    showAlert('error', err.message);
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  const session = await checkSession();
  if (!session) return;

  await loadCategoriesIntoSelect();
  await loadArticleList();

  document.querySelector('.admin-nav button[data-view="list"]').addEventListener('click', () => switchView('list'));
  document.querySelector('.admin-nav button[data-view="new"]').addEventListener('click', () => {
    resetForm();
    switchView('form');
  });
  document.querySelector('.admin-nav button[data-view="categories"]').addEventListener('click', () => {
    switchView('categories');
    loadCategoryManagement();
  });
  document.getElementById('category-form').addEventListener('submit', addCategory);
  document.getElementById('cancel-btn').addEventListener('click', () => {
    resetForm();
    switchView('list');
  });
  document.getElementById('article-form').addEventListener('submit', submitArticleForm);
  document.getElementById('photo_file').addEventListener('change', handlePhotoUpload);
  document.getElementById('image_url_manual').addEventListener('input', (e) => {
    if (e.target.value.trim()) togglePreview(e.target.value.trim());
  });
  document.getElementById('logout-btn').addEventListener('click', async () => {
    await fetch('/api/logout', { method: 'POST' });
    location.href = '/admin-diengaktual24/';
  });
});
