export async function onRequestGet({ request }) {
  const origin = new URL(request.url).origin;
  const body = `User-agent: *
Disallow: /admin-diengaktual24/
Disallow: /api/

Sitemap: ${origin}/sitemap.xml
`;
  return new Response(body, {
    headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'public, max-age=3600' },
  });
}
