function esc(str) {
  return (str ?? '').toString().replace(/&/g, '&amp;');
}

export async function onRequestGet({ env, request }) {
  const origin = new URL(request.url).origin;

  const { results } = await env.DB.prepare(
    `SELECT slug, updated_at FROM articles WHERE status = 'published' ORDER BY updated_at DESC LIMIT 5000`
  ).all();

  const urlEntries = results
    .map((a) => {
      const lastmod = (a.updated_at || '').split(' ')[0];
      return `  <url>
    <loc>${origin}/artikel/${esc(a.slug)}</loc>
    <lastmod>${lastmod}</lastmod>
  </url>`;
    })
    .join('\n');

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${origin}/</loc>
  </url>
${urlEntries}
</urlset>`;

  return new Response(xml, {
    headers: { 'Content-Type': 'application/xml; charset=utf-8', 'Cache-Control': 'public, max-age=1800' },
  });
}
