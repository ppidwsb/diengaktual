// GET /artikel/:slug — merender halaman artikel dengan meta tag Open Graph
// yang benar-benar terisi (judul, deskripsi, foto) supaya preview link di
// WhatsApp/Facebook/Twitter tampil bagus. Halaman statis biasa tidak bisa
// melakukan ini karena meta tag-nya harus terisi sebelum halaman dikirim ke crawler.

function esc(str) {
  return (str ?? '')
    .toString()
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function stripToText(content, max = 160) {
  const plain = (content || '').replace(/\s+/g, ' ').trim();
  return plain.length > max ? plain.slice(0, max - 1) + '…' : plain;
}

export async function onRequestGet({ env, params, request }) {
  const origin = new URL(request.url).origin;
  const slug = params.slug;

  const row = await env.DB.prepare(
    `SELECT a.*, c.name as category_name FROM articles a
     LEFT JOIN categories c ON a.category_id = c.id
     WHERE a.slug = ? AND a.status = 'published'`
  )
    .bind(slug)
    .first();

  if (!row) {
    if (env.ASSETS) {
      const res = await env.ASSETS.fetch(new URL('/404.html', origin));
      return new Response(res.body, { status: 404, headers: res.headers });
    }
    return new Response('Artikel tidak ditemukan.', { status: 404, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
  }

  await env.DB.prepare('UPDATE articles SET views = views + 1 WHERE id = ?').bind(row.id).run();

  const title = esc(row.title);
  const description = esc(row.excerpt || stripToText(row.content));
  const imageUrl = row.image_url
    ? (row.image_url.startsWith('/') ? `${origin}${row.image_url}` : row.image_url)
    : `${origin}/favicon.svg`;
  const canonical = `${origin}/artikel/${row.slug}`;

  const html = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${title} — Diengaktual24</title>
<meta name="description" content="${description}">
<link rel="canonical" href="${canonical}">

<meta property="og:type" content="article">
<meta property="og:site_name" content="Diengaktual24">
<meta property="og:title" content="${title}">
<meta property="og:description" content="${description}">
<meta property="og:image" content="${esc(imageUrl)}">
<meta property="og:url" content="${canonical}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${title}">
<meta name="twitter:description" content="${description}">
<meta name="twitter:image" content="${esc(imageUrl)}">

<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="mist-bar"></div>

<header class="site-header">
  <div class="wrap header-top">
    <span>Edisi Digital &middot; Dataran Tinggi Dieng, Jawa Tengah</span>
    <span class="clock" id="live-clock">--:--:-- WIB</span>
  </div>
  <div class="wrap header-main">
    <a href="/" class="brand">Dieng<span class="accent">aktual</span>24</a>
    <form class="search-box" id="search-form">
      <input type="text" id="search-input" placeholder="Cari berita…" autocomplete="off">
      <button type="submit">Cari</button>
    </form>
  </div>
  <nav class="categories" id="category-nav"></nav>
</header>

<main class="wrap">
  <div class="article-page" id="article-container" data-slug="${esc(row.slug)}">
    <a class="back-link" href="/">&larr; Kembali ke beranda</a>
    <span class="eyebrow">${esc(row.category_name || 'Berita')}</span>
    <h1>${title}</h1>
    <div class="meta-row">
      <span>Oleh ${esc(row.author)}</span>
      <span>${esc(row.created_at)}</span>
      <span>${row.views + 1} kali dibaca</span>
    </div>
    <img class="cover" src="${esc(imageUrl)}" alt="${title}">
    <div class="article-body">${row.content.split(/\n+/).filter((p) => p.trim()).map((p) => `<p>${esc(p)}</p>`).join('')}</div>
  </div>
</main>

<footer class="site-footer">
  <div class="wrap">
    <div class="foot-brand">Diengaktual24</div>
    <p>Menyajikan kabar dari dataran tinggi hingga panggung nasional — cepat, ringkas, dan dapat dipercaya.</p>
    <div class="foot-bottom">
      <span>&copy; <span id="year"></span> Diengaktual24. Seluruh hak cipta dilindungi.</span>
      <span>Dipublikasikan dari Wonosobo, Jawa Tengah</span>
    </div>
  </div>
</footer>

<script>document.getElementById('year').textContent = new Date().getFullYear();</script>
<script src="/assets/js/main.js" data-ssr="1"></script>
</body>
</html>`;

  return new Response(html, {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'public, max-age=60, s-maxage=300',
    },
  });
}
