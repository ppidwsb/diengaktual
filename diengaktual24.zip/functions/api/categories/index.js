import { requireAdmin, json, slugify } from '../_lib/auth.js';

export async function onRequestGet({ env }) {
  const { results } = await env.DB.prepare('SELECT id, name, slug FROM categories ORDER BY name ASC').all();
  return json({ categories: results });
}

export async function onRequestPost({ request, env }) {
  const admin = await requireAdmin(request, env);
  if (!admin) return json({ error: 'Perlu login sebagai admin.' }, 401);

  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: 'Body tidak valid.' }, 400);
  }

  const name = (body.name || '').trim();
  if (!name) return json({ error: 'Nama kategori wajib diisi.' }, 400);
  const slug = slugify(name);

  try {
    await env.DB.prepare('INSERT INTO categories (name, slug) VALUES (?, ?)').bind(name, slug).run();
  } catch {
    return json({ error: 'Kategori dengan nama itu sudah ada.' }, 400);
  }

  return json({ success: true });
}
