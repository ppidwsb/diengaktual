import { requireAdmin, json, slugify } from '../../_lib/auth.js';

// PUT /api/categories/:id — ubah nama kategori (khusus admin)
export async function onRequestPut({ request, env, params }) {
  const admin = await requireAdmin(request, env);
  if (!admin) return json({ error: 'Perlu login sebagai admin.' }, 401);

  const id = params.id;
  const existing = await env.DB.prepare('SELECT * FROM categories WHERE id = ?').bind(id).first();
  if (!existing) return json({ error: 'Kategori tidak ditemukan.' }, 404);

  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: 'Body tidak valid.' }, 400);
  }

  const name = (body.name || '').trim();
  if (!name) return json({ error: 'Nama kategori wajib diisi.' }, 400);
  const slug = slugify(name);

  try {
    await env.DB.prepare('UPDATE categories SET name = ?, slug = ? WHERE id = ?').bind(name, slug, id).run();
  } catch {
    return json({ error: 'Kategori dengan nama itu sudah ada.' }, 400);
  }

  return json({ success: true });
}

// DELETE /api/categories/:id — hapus kategori (khusus admin)
// Artikel yang memakai kategori ini akan dilepas (category_id jadi kosong), bukan ikut terhapus.
export async function onRequestDelete({ request, env, params }) {
  const admin = await requireAdmin(request, env);
  if (!admin) return json({ error: 'Perlu login sebagai admin.' }, 401);

  const id = params.id;
  await env.DB.prepare('UPDATE articles SET category_id = NULL WHERE category_id = ?').bind(id).run();
  await env.DB.prepare('DELETE FROM categories WHERE id = ?').bind(id).run();

  return json({ success: true });
}
