import { requireAdmin, json } from '../_lib/auth.js';

export async function onRequestGet({ request, env }) {
  const admin = await requireAdmin(request, env);
  if (!admin) return json({ authenticated: false }, 401);
  return json({ authenticated: true, username: admin.sub });
}
