import { verifyPassword } from '../_lib/crypto.js';
import { signJWT, sessionCookie, json } from '../_lib/auth.js';

const MAX_AGE = 60 * 60 * 24; // 24 jam

export async function onRequestPost({ request, env }) {
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: 'Body tidak valid.' }, 400);
  }

  const { username, password } = body;
  if (!username || !password) {
    return json({ error: 'Username dan password wajib diisi.' }, 400);
  }

  const admin = await env.DB.prepare('SELECT * FROM admins WHERE username = ?')
    .bind(username.trim())
    .first();

  if (!admin) {
    // Samakan pesan agar tidak bocorkan username valid/tidak
    return json({ error: 'Username atau password salah.' }, 401);
  }

  const valid = await verifyPassword(password, admin.salt, admin.password_hash);
  if (!valid) {
    return json({ error: 'Username atau password salah.' }, 401);
  }

  const token = await signJWT({ sub: admin.username, role: 'admin' }, env.JWT_SECRET, MAX_AGE);

  return json(
    { success: true, username: admin.username },
    200,
    { 'Set-Cookie': sessionCookie(token, MAX_AGE) }
  );
}
