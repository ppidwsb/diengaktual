import { requireAdmin, json, slugify, safeDeleteR2 } from '../../_lib/auth.js';

// GET /api/articles/:idOrSlug
// - Jika angka -> dicari berdasar id (dipakai admin utk edit; boleh draft jika admin login)
// - Jika bukan angka -> dicari berdasar slug (dipakai halaman publik; wajib published kecuali admin login)
export async function onRequestGet({ request, env, params }) {
  const idOrSlug = params.id;
  const isNumeric = /^\d+$/.test(idOrSlug);

  const row = await env.DB.prepare(
    `SELECT a.*, c.name as category_name, c.slug as category_slug
     FROM articles a LEFT JOIN categories c ON a.category_id = c.id
     WHERE a.${isNumeric ? 'id' : 'slug'} = ?`
  )
    .bind(idOrSlug)
    .first();

  if (!row) return json({ error: 'Artikel tidak ditemukan.' }, 404);

  if (row.status !== 'published') {
    const admin = await requireAdmin(request, env);
    if (!admin) return json({ error: 'Artikel tidak ditemukan.' }, 404);
  } else if (!isNumeric) {
    // Tambah view count hanya untuk akses publik via slug pada artikel published
    await env.DB.prepare('UPDATE articles SET views = views + 1 WHERE id = ?').bind(row.id).run();
    row.views += 1;
  }

  return json({ article: row });
}

// PUT /api/articles/:id — ubah artikel (khusus admin)
export async function onRequestPut({ request, env, params }) {
  const admin = await requireAdmin(request, env);
  if (!admin) return json({ error: 'Perlu login sebagai admin.' }, 401);

  const id = params.id;
  const existing = await env.DB.prepare('SELECT * FROM articles WHERE id = ?').bind(id).first();
  if (!existing) return json({ error: 'Artikel tidak ditemukan.' }, 404);

  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: 'Body tidak valid.' }, 400);
  }

  const title = (body.title ?? existing.title).trim();
  const content = (body.content ?? existing.content).trim();
  const excerpt = (body.excerpt ?? existing.excerpt ?? '').trim().slice(0, 300);
  const imageUrl = (body.image_url ?? existing.image_url ?? '').trim();
  const categoryId = body.category_id ?? existing.category_id;
  const status = body.status === 'published' || body.status === 'draft' ? body.status : existing.status;

  if (!title || title.length < 5) return json({ error: 'Judul minimal 5 karakter.' }, 400);
  if (!content || content.length < 20) return json({ error: 'Isi berita minimal 20 karakter.' }, 400);
  if (imageUrl && !/^https?:\/\//i.test(imageUrl)) {
    return json({ error: 'URL foto harus diawali http:// atau https://' }, 400);
  }

  let slug = existing.slug;
  if (title !== existing.title) {
    let baseSlug = slugify(title);
    slug = baseSlug;
    let attempt = 0;
    while (attempt < 5) {
      const clash = await env.DB.prepare('SELECT id FROM articles WHERE slug = ? AND id != ?').bind(slug, id).first();
      if (!clash) break;
      attempt++;
      slug = `${baseSlug}-${Date.now().toString(36).slice(-4)}`;
    }
  }

  await env.DB.prepare(
    `UPDATE articles SET title=?, slug=?, category_id=?, excerpt=?, content=?, image_url=?, status=?, updated_at=CURRENT_TIMESTAMP
     WHERE id=?`
  )
    .bind(title, slug, categoryId, excerpt, content, imageUrl || null, status, id)
    .run();

  // Jika foto diganti dan foto lama tersimpan di R2 kita, hapus yang lama agar tidak jadi sampah.
  if (existing.image_url && existing.image_url !== imageUrl) {
    await safeDeleteR2(env, existing.image_url);
  }

  return json({ success: true, slug });
}

// DELETE /api/articles/:id — hapus artikel (khusus admin)
export async function onRequestDelete({ request, env, params }) {
  const admin = await requireAdmin(request, env);
  if (!admin) return json({ error: 'Perlu login sebagai admin.' }, 401);

  const id = params.id;
  const existing = await env.DB.prepare('SELECT image_url FROM articles WHERE id = ?').bind(id).first();
  await env.DB.prepare('DELETE FROM articles WHERE id = ?').bind(id).run();
  if (existing?.image_url) {
    await safeDeleteR2(env, existing.image_url);
  }
  return json({ success: true });
}
