import { requireAdmin, json, slugify } from '../../_lib/auth.js';

// GET /api/articles
// Query params:
//   kategori=<slug>   filter kategori
//   q=<kata kunci>    cari di judul
//   page=<n>          default 1
//   limit=<n>         default 12, maksimal 50
//   all=1             (hanya efektif jika login admin) tampilkan draft juga
export async function onRequestGet({ request, env }) {
  const url = new URL(request.url);
  const kategori = url.searchParams.get('kategori');
  const q = url.searchParams.get('q');
  const page = Math.max(1, parseInt(url.searchParams.get('page') || '1', 10));
  const limit = Math.min(50, Math.max(1, parseInt(url.searchParams.get('limit') || '12', 10)));
  const offset = (page - 1) * limit;
  const wantAll = url.searchParams.get('all') === '1';

  const admin = wantAll ? await requireAdmin(request, env) : null;
  const showAllStatus = wantAll && !!admin;

  const conditions = [];
  const params = [];

  if (!showAllStatus) {
    conditions.push('a.status = ?');
    params.push('published');
  }
  if (kategori) {
    conditions.push('c.slug = ?');
    params.push(kategori);
  }
  if (q) {
    conditions.push('a.title LIKE ?');
    params.push(`%${q}%`);
  }

  const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const listQuery = `
    SELECT a.id, a.title, a.slug, a.excerpt, a.image_url, a.status, a.author,
           a.views, a.created_at, a.updated_at, c.name as category_name, c.slug as category_slug
    FROM articles a
    LEFT JOIN categories c ON a.category_id = c.id
    ${whereClause}
    ORDER BY a.created_at DESC
    LIMIT ? OFFSET ?
  `;
  const countQuery = `
    SELECT COUNT(*) as total
    FROM articles a
    LEFT JOIN categories c ON a.category_id = c.id
    ${whereClause}
  `;

  const { results } = await env.DB.prepare(listQuery).bind(...params, limit, offset).all();
  const countRow = await env.DB.prepare(countQuery).bind(...params).first();

  return json({
    articles: results,
    page,
    limit,
    total: countRow.total,
    totalPages: Math.ceil(countRow.total / limit),
  });
}

// POST /api/articles — buat artikel baru (khusus admin)
export async function onRequestPost({ request, env }) {
  const admin = await requireAdmin(request, env);
  if (!admin) return json({ error: 'Perlu login sebagai admin.' }, 401);

  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: 'Body tidak valid.' }, 400);
  }

  const title = (body.title || '').trim();
  const content = (body.content || '').trim();
  const excerpt = (body.excerpt || '').trim().slice(0, 300);
  const imageUrl = (body.image_url || '').trim();
  const categoryId = body.category_id || null;
  const status = body.status === 'published' ? 'published' : 'draft';

  if (!title || title.length < 5) return json({ error: 'Judul minimal 5 karakter.' }, 400);
  if (!content || content.length < 20) return json({ error: 'Isi berita minimal 20 karakter.' }, 400);
  if (imageUrl && !/^https?:\/\//i.test(imageUrl)) {
    return json({ error: 'URL foto harus diawali http:// atau https://' }, 400);
  }

  let baseSlug = slugify(title);
  let slug = baseSlug;
  let attempt = 0;
  while (attempt < 5) {
    const exists = await env.DB.prepare('SELECT id FROM articles WHERE slug = ?').bind(slug).first();
    if (!exists) break;
    attempt++;
    slug = `${baseSlug}-${Date.now().toString(36).slice(-4)}`;
  }

  const result = await env.DB.prepare(
    `INSERT INTO articles (title, slug, category_id, excerpt, content, image_url, status, author, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`
  )
    .bind(title, slug, categoryId, excerpt, content, imageUrl || null, status, admin.sub)
    .run();

  return json({ success: true, id: result.meta.last_row_id, slug });
}
