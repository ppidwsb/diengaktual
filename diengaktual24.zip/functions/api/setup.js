import { generateSaltHex, hashPassword } from '../_lib/crypto.js';
import { json } from '../_lib/auth.js';

// POST /api/setup — hanya bisa dipakai SEKALI (selama tabel admins masih kosong)
// Wajib header X-Setup-Key yang cocok dengan secret env.SETUP_KEY.
export async function onRequestPost({ request, env }) {
  const key = request.headers.get('X-Setup-Key');
  if (!env.SETUP_KEY || key !== env.SETUP_KEY) {
    return json({ error: 'Tidak diizinkan.' }, 401);
  }

  const existing = await env.DB.prepare('SELECT COUNT(*) as c FROM admins').first();
  if (existing.c > 0) {
    return json({ error: 'Akun admin sudah pernah dibuat. Setup ditutup.' }, 400);
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: 'Body tidak valid.' }, 400);
  }

  const { username, password } = body;
  if (!username || typeof username !== 'string' || username.trim().length < 3) {
    return json({ error: 'Username minimal 3 karakter.' }, 400);
  }
  if (!password || typeof password !== 'string' || password.length < 8) {
    return json({ error: 'Password minimal 8 karakter.' }, 400);
  }

  const salt = generateSaltHex();
  const hash = await hashPassword(password, salt);

  await env.DB.prepare(
    'INSERT INTO admins (username, password_hash, salt) VALUES (?, ?, ?)'
  )
    .bind(username.trim(), hash, salt)
    .run();

  return json({ success: true, message: 'Akun admin berhasil dibuat. Silakan login.' });
}
