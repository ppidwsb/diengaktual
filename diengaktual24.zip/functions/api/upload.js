import { requireAdmin, json } from '../_lib/auth.js';

const ALLOWED_EXT = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/gif': 'gif',
  'image/webp': 'webp',
};
const MAX_SIZE = 5 * 1024 * 1024; // 5MB — cukup untuk foto berita, tetap ringan

// Deteksi tipe file dari isi berkas (magic bytes), bukan dari header Content-Type
// yang bisa dipalsukan klien — ini bagian dari validasi "aman".
function detectImageType(buffer) {
  const bytes = new Uint8Array(buffer.slice(0, 12));
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return 'image/jpeg';
  if (
    bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47 &&
    bytes[4] === 0x0d && bytes[5] === 0x0a && bytes[6] === 0x1a && bytes[7] === 0x0a
  ) return 'image/png';
  if (bytes[0] === 0x47 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x38) return 'image/gif';
  if (
    bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46 &&
    bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50
  ) return 'image/webp';
  return null;
}

// POST /api/upload — multipart/form-data dengan field "file" (khusus admin)
export async function onRequestPost({ request, env }) {
  const admin = await requireAdmin(request, env);
  if (!admin) return json({ error: 'Perlu login sebagai admin.' }, 401);

  if (!env.BUCKET) {
    return json({ error: 'Penyimpanan foto (R2) belum dikonfigurasi di server. Lihat README.' }, 500);
  }

  const contentType = request.headers.get('content-type') || '';
  if (!contentType.includes('multipart/form-data')) {
    return json({ error: 'Format unggahan tidak didukung.' }, 400);
  }

  let form;
  try {
    form = await request.formData();
  } catch {
    return json({ error: 'Gagal membaca berkas.' }, 400);
  }

  const file = form.get('file');
  if (!file || typeof file === 'string') {
    return json({ error: 'Berkas foto tidak ditemukan.' }, 400);
  }
  if (file.size > MAX_SIZE) {
    return json({ error: 'Ukuran foto maksimal 5MB.' }, 400);
  }

  const buffer = await file.arrayBuffer();
  const detectedType = detectImageType(buffer);
  const ext = ALLOWED_EXT[detectedType];
  if (!ext) {
    return json({ error: 'Berkas harus berupa gambar JPG, PNG, GIF, atau WEBP yang valid.' }, 400);
  }

  const key = `${Date.now().toString(36)}-${crypto.randomUUID().slice(0, 8)}.${ext}`;

  await env.BUCKET.put(key, buffer, {
    httpMetadata: { contentType: detectedType, cacheControl: 'public, max-age=31536000, immutable' },
  });

  return json({ success: true, url: `/media/${key}` });
}
