// JWT (HMAC-SHA256) minimal, khusus session admin. Tanpa dependency npm.

function b64urlEncode(bytesOrStr) {
  let str;
  if (typeof bytesOrStr === 'string') {
    str = btoa(unescape(encodeURIComponent(bytesOrStr)));
  } else {
    str = btoa(String.fromCharCode(...new Uint8Array(bytesOrStr)));
  }
  return str.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function b64urlDecodeToString(b64url) {
  let b64 = b64url.replace(/-/g, '+').replace(/_/g, '/');
  while (b64.length % 4) b64 += '=';
  return decodeURIComponent(escape(atob(b64)));
}

async function hmac(secret, message) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    'raw',
    enc.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(message));
  return b64urlEncode(sig);
}

export async function signJWT(payload, secret, expiresInSeconds = 60 * 60 * 24) {
  const header = { alg: 'HS256', typ: 'JWT' };
  const now = Math.floor(Date.now() / 1000);
  const fullPayload = { ...payload, iat: now, exp: now + expiresInSeconds };
  const headerB64 = b64urlEncode(JSON.stringify(header));
  const payloadB64 = b64urlEncode(JSON.stringify(fullPayload));
  const signature = await hmac(secret, `${headerB64}.${payloadB64}`);
  return `${headerB64}.${payloadB64}.${signature}`;
}

export async function verifyJWT(token, secret) {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [headerB64, payloadB64, signature] = parts;
  const expected = await hmac(secret, `${headerB64}.${payloadB64}`);
  if (expected !== signature) return null;
  try {
    const payload = JSON.parse(b64urlDecodeToString(payloadB64));
    const now = Math.floor(Date.now() / 1000);
    if (payload.exp && now > payload.exp) return null;
    return payload;
  } catch {
    return null;
  }
}

export function getCookie(request, name) {
  const cookieHeader = request.headers.get('Cookie') || '';
  const match = cookieHeader.match(new RegExp(`(?:^|; )${name}=([^;]*)`));
  return match ? decodeURIComponent(match[1]) : null;
}

export function sessionCookie(token, maxAgeSeconds = 60 * 60 * 24) {
  return `session=${encodeURIComponent(token)}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${maxAgeSeconds}`;
}

export function clearSessionCookie() {
  return `session=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0`;
}

// Mengembalikan payload admin jika request punya session valid, else null.
export async function requireAdmin(request, env) {
  const token = getCookie(request, 'session');
  if (!token) return null;
  const payload = await verifyJWT(token, env.JWT_SECRET);
  if (!payload || payload.role !== 'admin') return null;
  return payload;
}

export function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', ...extraHeaders },
  });
}

export function slugify(text) {
  return text
    .toString()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .slice(0, 90);
}

// Mengembalikan nama-key R2 jika url adalah foto internal ("/media/xxx.jpg"), else null.
// Dipakai untuk membersihkan foto lama di R2 saat artikel dihapus/foto diganti.
export function r2KeyFromUrl(url) {
  if (!url || typeof url !== 'string') return null;
  const match = url.match(/^\/media\/([a-z0-9-]+\.(?:jpg|png|gif|webp))$/i);
  return match ? match[1] : null;
}

export async function safeDeleteR2(env, url) {
  const key = r2KeyFromUrl(url);
  if (!key || !env.BUCKET) return;
  try {
    await env.BUCKET.delete(key);
  } catch (e) {
    // Jangan gagalkan request utama hanya karena bersih-bersih foto gagal.
    console.error('Gagal hapus foto lama di R2:', e);
  }
}
