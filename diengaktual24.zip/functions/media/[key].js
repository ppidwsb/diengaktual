// GET /media/:key — menyajikan foto yang tersimpan di R2. Publik & read-only,
// tidak ada operasi tulis di sini sama sekali.
export async function onRequestGet({ env, params }) {
  if (!env.BUCKET) return new Response('Penyimpanan foto belum dikonfigurasi.', { status: 500 });

  const key = params.key;
  // Cegah path traversal / akses ke key aneh-aneh
  if (!/^[a-z0-9-]+\.(jpg|png|gif|webp)$/i.test(key)) {
    return new Response('Not found', { status: 404 });
  }

  const object = await env.BUCKET.get(key);
  if (!object) return new Response('Not found', { status: 404 });

  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set('etag', object.httpEtag);
  if (!headers.get('Cache-Control')) {
    headers.set('Cache-Control', 'public, max-age=31536000, immutable');
  }

  return new Response(object.body, { headers });
}
